#!/usr/bin/env bash
set -Eeuo pipefail
root=/var/tmp/faas-metal-smoke-managed-pg-mega-pr-2cd325e9
user=kucukarslanhuseyinpoyraz_gmail_c
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export TMPDIR=/run/mppr-2cd325e9 GOCACHE="$root/go-build" GOMODCACHE="$root/go-mod" GOPATH="$root/go-path"
export GOTOOLCHAIN=local GOFLAGS=-p=1 GOMAXPROCS=2 GOGC=50 GOMEMLIMIT=2GiB
export GOLANGCI_LINT_CACHE="$root/lint-cache"
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=safe.directory GIT_CONFIG_VALUE_0="$root/source"
mkdir -p "$TMPDIR" "$root/build" "$root/go-path" "$root/lint-cache"
chmod 1777 "$TMPDIR"
chown "$user:$user" "$root/build" "$root/go-path" "$root/lint-cache"
cd "$root/source"
git apply "$root/integration.patch"
sha256sum -c "$root/final-source-hashes.sha256" > "$root/source-match-before.log"
runuser -u "$user" -- git init -q -b validation --template=''
runuser -u "$user" -- git add .
runuser -u "$user" -- git -c user.name=GregaleValidation -c user.email=validation@localhost -c core.hooksPath=/dev/null commit -qm 'Pinned integrated source 9917c420f2ff484ebf87a6379e791a3c852fe911'
runuser -u "$user" -- /usr/lib/postgresql/16/bin/pg_ctl -D "$root/pg-data" -l "$root/postgres.log" -o "-h 127.0.0.1 -p 55437 -k $root/pg-socket -c max_connections=150 -c shared_buffers=128MB" -w start
cleanup() {
 local rc=$?
 trap - EXIT
 runuser -u "$user" -- /usr/lib/postgresql/16/bin/pg_ctl -D "$root/pg-data" -m fast -w stop || rc=1
 if [ "${metal_locked:-0}" -eq 1 ]; then make leakcheck || rc=1; fi
 exit "$rc"
}
trap cleanup EXIT
export DATABASE_URL='postgres://postgres@127.0.0.1:55437/gregale_fresh?sslmode=disable'
export FAAS_PGTEST_TEMPLATE_DATABASE=1
printf 'integrated snapshot: 9917c420f2ff484ebf87a6379e791a3c852fe911
'
uname -a
/usr/local/bin/go version
runuser -u "$user" --preserve-environment -- /usr/local/bin/go test -race -json -count=1 -timeout=18m ./... > "$root/linux-unit.json" 2>&1
printf '0
' > "$root/linux-unit.exit"
printf 'portable suite passed
'
runuser -u "$user" --preserve-environment -- make GO=/usr/local/bin/go BINDIR="$root/build" VERSION=9917c420f2ff484ebf87a6379e791a3c852fe911 build > "$root/build.log" 2>&1
printf '0
' > "$root/build.exit"
printf 'build passed
'
runuser -u "$user" --preserve-environment -- /usr/local/bin/go tool golangci-lint run --allow-parallel-runners --timeout=20m > "$root/lint.log" 2>&1
printf '0
' > "$root/lint.exit"
printf 'lint passed
'
# These are source/deployment gates; SDK regeneration is verified on the caller.
runuser -u "$user" --preserve-environment -- make GO=/usr/local/bin/go capabilities-check pricing-check docs-links-check api-hosting-contract-check api-hosting-scorecard-check egress-check environment-preflight-action-check generate-check > "$root/contracts.log" 2>&1
printf 'contracts passed
'
export FAAS_TEST_KERNEL=/srv/fc/base/vmlinux-6.1.134 FAAS_TEST_FC_VERSION=1.7.0 FAAS_TEST_REFERENCE_SSD=0
for service in faas-vmmd.service faas-builderd.service faas-imaged.service faas-gatewayd-internal.service; do
 if systemctl is-active --quiet "$service"; then printf 'active daemon: %s
' "$service" >&2; exit 1; fi
done
exec 9>/var/lock/faas-builder-acceptance.lock
flock -w 1800 9
metal_locked=1
make leakcheck
base="$root/fixtures/base-skeleton"
layer="$root/fixtures/layer-skeleton"
mkdir -p "$base/bin" "$base/sbin" "$base/etc/faas" "$layer/upper/etc/faas" "$layer/upper/tmp"
for d in dev overlay proc run sys sys/fs/cgroup tmp; do mkdir -p "$base/$d"; done
CGO_ENABLED=0 /usr/local/bin/go build -trimpath -buildvcs=false -o "$base/sbin/init" ./guest/init
install -m 0755 /usr/bin/busybox "$base/bin/busybox"
for name in bin/sh bin/ash bin/cat; do ln -sfn /bin/busybox "$base/$name"; done
printf '%s
' '{"entrypoint":["/bin/busybox","httpd","-f","-p","8080","-h","/"],"port":8080}' > "$layer/upper/etc/faas/app.json"
export FAAS_TEST_BASE_ROOTFS="$root/fixtures/hello-base.ext4" FAAS_TEST_LAYER_ROOTFS="$root/fixtures/hello-layer.ext4"
truncate -s 64M "$FAAS_TEST_BASE_ROOTFS"
mkfs.ext4 -q -O '^has_journal' -d "$base" -L faas-metal-smoke -F "$FAAS_TEST_BASE_ROOTFS"
truncate -s 16M "$FAAS_TEST_LAYER_ROOTFS"
mkfs.ext4 -q -O '^has_journal' -d "$layer" -L faas-metal-layer -F "$FAAS_TEST_LAYER_ROOTFS"
chmod 0644 "$FAAS_TEST_BASE_ROOTFS" "$FAAS_TEST_LAYER_ROOTFS"
export RUN_REGEX='^(TestMetalResourceRestartPrepared|TestResourceRestartPrepared|TestMetalResourcePrepared|TestResourcePrepared|TestPreparedNetwork|TestMetalResourceLinks|TestResourceLinks|TestMetalResourcePlacement|TestMetalResourceAssets|TestResourcePlacement|TestResourceAssets|TestMetalResourceJournal|TestResourceJournal|TestMetalRestartQuarantine|TestRestartQuarantine|TestMetalFailureOutbox|TestMetalTeardownRetainsOwnership|TestMetalSchedulerRetainsAccounting|TestMetalAppAdmission|TestAppAdmission|TestFailureReport|TestRecoveredFailureReport|TestLoadConfigResourceJournal)'
make GO=/usr/local/bin/go PKGS='./pkg/fcvm ./pkg/sched ./cmd/vmmd' RUN_ARGS='-timeout=20m -v' test-metal > "$root/metal.log" 2>&1
printf '0
' > "$root/metal.exit"
make leakcheck
sha256sum -c "$root/final-source-hashes.sha256" > "$root/source-match-after.log"
printf 'integrated diagnostic passed
'
