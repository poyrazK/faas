#!/usr/bin/env bash
set -Eeuo pipefail
root=/var/tmp/faas-metal-smoke-managed-pg-mega-pr-2cd325e9
user=kucukarslanhuseyinpoyraz_gmail_c
export PATH=/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin
export GOCACHE="$root/go-build" GOMODCACHE="$root/go-mod" GOPATH="$root/go-path"
export GOTOOLCHAIN=local GOFLAGS=-p=1 GOMAXPROCS=2 GOGC=50 GOMEMLIMIT=1536MiB
export TMPDIR=/run/mppr-2cd325e9
mkdir -p "$TMPDIR" "$root/source" "$root/main" "$root/pg-socket"
chmod 1777 "$TMPDIR"
sha256sum -c "$root/archive-hashes.sha256"
tar -xzf "$root/source.tar.gz" -C "$root/source"
tar -xzf "$root/main.tar.gz" -C "$root/main"
chown -R "$user:$user" "$root/source" "$root/main" "$root/pg-socket"
runuser -u "$user" -- /usr/lib/postgresql/16/bin/initdb -D "$root/pg-data" -U postgres -A trust --no-locale -E UTF8
runuser -u "$user" -- /usr/lib/postgresql/16/bin/pg_ctl -D "$root/pg-data" -l "$root/postgres.log" -o "-h 127.0.0.1 -p 55437 -k $root/pg-socket -c max_connections=150 -c shared_buffers=128MB" -w start
trap 'runuser -u "$user" -- /usr/lib/postgresql/16/bin/pg_ctl -D "$root/pg-data" -m fast -w stop' EXIT
/usr/bin/createdb -h 127.0.0.1 -p 55437 -U postgres gregale_upgrade
/usr/bin/createdb -h 127.0.0.1 -p 55437 -U postgres gregale_fresh
export DATABASE_URL=postgres://postgres@127.0.0.1:55437/gregale_upgrade?sslmode=disable
cd "$root/main"
runuser -u "$user" --preserve-environment -- /usr/local/bin/go run ./cmd/migrate > "$root/migrate-main.log" 2>&1
cd "$root/source"
runuser -u "$user" --preserve-environment -- /usr/local/bin/go run ./cmd/migrate > "$root/migrate-upgrade.log" 2>&1
runuser -u "$user" --preserve-environment -- /usr/local/bin/go run ./cmd/migrate > "$root/migrate-replay.log" 2>&1
runuser -u "$user" --preserve-environment -- /usr/local/bin/go run ./cmd/schema-dump -o "$root/upgrade-schema.sql" > "$root/upgrade-schema.log" 2>&1
export DATABASE_URL=postgres://postgres@127.0.0.1:55437/gregale_fresh?sslmode=disable
runuser -u "$user" --preserve-environment -- /usr/local/bin/go run ./cmd/schema-dump -o "$root/fresh-schema.sql" > "$root/fresh-schema.log" 2>&1
diff -u "$root/upgrade-schema.sql" "$root/fresh-schema.sql" > "$root/schema-comparison.log"
printf 'schema phase passed: main upgrade, replay, fresh migration, identical schema
'
